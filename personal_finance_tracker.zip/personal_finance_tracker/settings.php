<?php
/**
 * SYSTEM SETTINGS
 * Handles configuration for currency, date formats, and localization.
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

// Security: Check login status
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

/**
 * Note: For a full implementation, you would store these in a 'settings' table.
 * For now, this serves the UI for your International System.
 */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_settings'])) {
    // Logic to update system preferences would go here
    $status_msg = "<div class='alert alert-success border-0 shadow-sm'>✅ System configurations updated successfully!</div>";
}
?>

<style>
    .settings-card {
        border: none;
        border-radius: 12px;
        background: #fff;
    }
    .settings-sidebar .list-group-item {
        border: none;
        padding: 15px 20px;
        font-weight: 600;
        color: #4e73df;
    }
    .settings-sidebar .list-group-item.active {
        background-color: #f8f9fc;
        color: #224abe;
        border-left: 4px solid #4e73df;
    }
    .section-header {
        border-bottom: 2px solid #f8f9fc;
        padding-bottom: 10px;
        margin-bottom: 20px;
        color: #3a3b45;
        font-weight: 700;
    }
    .form-check-input:checked {
        background-color: #1cc88a;
        border-color: #1cc88a;
    }
</style>

<div class="container-fluid mt-4">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800 fw-bold">System Settings</h1>
    </div>

    <?php echo $status_msg; ?>

    <div class="row">
        <div class="col-lg-3 mb-4">
            <div class="card shadow-sm settings-sidebar">
                <div class="list-group list-group-flush">
                    <a href="#" class="list-group-item active"><i class="fas fa-cog me-2"></i> General</a>
                    <a href="profile.php" class="list-group-item"><i class="fas fa-user-shield me-2"></i> Account Security</a>
                    <a href="manage_categories.php" class="list-group-item"><i class="fas fa-list me-2"></i> Categories</a>
                    <a href="#" class="list-group-item text-danger"><i class="fas fa-trash-alt me-2"></i> Data Cleanup</a>
                </div>
            </div>
        </div>

        <div class="col-lg-9">
            <form action="settings.php" method="POST">
                <div class="card shadow-sm settings-card p-4">
                    
                    <div class="section-header">
                        <i class="fas fa-globe-africa me-2"></i> Regional & Localization
                    </div>
                    <div class="row mb-4">
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-muted">Primary Currency</label>
                            <select name="currency" class="form-select">
                                <option value="KES" selected>Kenyan Shilling (KES)</option>
                                <option value="USD">US Dollar (USD)</option>
                                <option value="EUR">Euro (EUR)</option>
                                <option value="GBP">British Pound (GBP)</option>
                            </select>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label small fw-bold text-muted">Date Format</label>
                            <select name="date_format" class="form-select">
                                <option value="Y-m-d">YYYY-MM-DD (2026-03-09)</option>
                                <option value="d/m/Y" selected>DD/MM/YYYY (09/03/2026)</option>
                                <option value="M d, Y">Month DD, YYYY</option>
                            </select>
                        </div>
                    </div>

                    <div class="section-header">
                        <i class="fas fa-bell me-2"></i> Preferences
                    </div>
                    <div class="mb-3">
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" id="emailNotif" checked>
                            <label class="form-check-label" for="emailNotif">Enable Email Weekly Summaries</label>
                        </div>
                        <div class="form-check form-switch mb-2">
                            <input class="form-check-input" type="checkbox" id="budgetAlert" checked>
                            <label class="form-check-label" for="budgetAlert">Alert when exceeding monthly budget</label>
                        </div>
                        <div class="form-check form-switch">
                            <input class="form-check-input" type="checkbox" id="darkMode">
                            <label class="form-check-label" for="darkMode">Interface Dark Mode (Beta)</label>
                        </div>
                    </div>

                    <hr class="my-4">

                    <div class="d-flex justify-content-end">
                        <button type="reset" class="btn btn-light me-2">Reset to Defaults</button>
                        <button type="submit" name="save_settings" class="btn btn-primary px-4 shadow-sm">
                            <i class="fas fa-check me-2"></i>Save Configuration
                        </button>
                    </div>
                </div>
            </form>

            <div class="card mt-4 border-0 shadow-sm bg-light">
                <div class="card-body p-3">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-info-circle text-primary me-3 fa-2x"></i>
                        <div>
                            <p class="mb-0 small fw-bold">System Information</p>
                            <p class="mb-0 text-muted small">International Finance Tracker v1.0.4 | Server: <?php echo $_SERVER['SERVER_SOFTWARE']; ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>