<?php
/**
 * REGISTER PAGE
 * Handles new user account creation.
 */

// 1. Start the session
session_start();

// 2. Include the database connection
require_once 'config/db.php';

// 3. Logic to handle the form when the "Register" button is clicked
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Get data from the form
    // mysqli_real_escape_string protects against SQL injection
    $fullname = mysqli_real_escape_string($conn, $_POST['fullname']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    // 4. Basic Validation
    if ($password !== $confirm_password) {
        $error = "Passwords do not match.";
    } else {
        // Check if email already exists in the database
        $check_email = "SELECT id FROM users WHERE email = '$email'";
        $result = mysqli_query($conn, $check_email);

        if (mysqli_num_rows($result) > 0) {
            $error = "This email is already registered.";
        } else {
            // 5. Password Hashing (Security)
            // NEVER store plain-text passwords. PASSWORD_DEFAULT uses a strong algorithm.
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);

            // 6. Insert the new user into the database
            $sql = "INSERT INTO users (full_name, email, password) VALUES ('$fullname', '$email', '$hashed_password')";

            if (mysqli_query($conn, $sql)) {
                // Registration successful! Redirect to login page
                $_SESSION['success_message'] = "Account created successfully! Please login.";
                header("Location: login.php");
                exit();
            } else {
                $error = "Something went wrong. Please try again.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Register - Personal Finance Tracker</title>
    <style>
        /* Internal CSS for a "Good Looking" professional interface */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f4f7f6;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .register-card {
            background: #fff;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0,0,0,0.08);
            width: 100%;
            max-width: 450px;
        }
        h2 { text-align: center; color: #333; margin-bottom: 20px; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; color: #555; font-weight: 600; }
        input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            box-sizing: border-box;
        }
        .btn {
            width: 100%;
            padding: 12px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 6px;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background 0.3s;
        }
        .btn:hover { background-color: #0056b3; }
        .error { color: #721c24; background: #f8d7da; padding: 10px; border-radius: 6px; margin-bottom: 15px; font-size: 14px; text-align: center; }
        .login-link { text-align: center; margin-top: 20px; font-size: 14px; color: #666; }
        .login-link a { color: #007bff; text-decoration: none; }
    </style>
</head>
<body>

<div class="register-card">
    <h2>Create Account</h2>

    <?php if (isset($error)): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form action="register.php" method="POST">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="fullname" required placeholder="John Doe">
        </div>
        <div class="form-group">
            <label>Email Address</label>
            <input type="email" name="email" required placeholder="example@mail.com">
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required placeholder="Create a password">
        </div>
        <div class="form-group">
            <label>Confirm Password</label>
            <input type="password" name="confirm_password" required placeholder="Repeat password">
        </div>
        <button type="submit" class="btn">Register Account</button>
    </form>

    <div class="login-link">
        Already have an account? <a href="login.php">Login here</a>
    </div>
</div>

</body>
</html>