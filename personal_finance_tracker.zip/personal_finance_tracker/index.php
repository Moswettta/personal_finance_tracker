<?php
/**
 * PERSONAL FINANCE TRACKER - ENTRY POINT
 * This file handles the initial landing logic for the system.
 */

// 1. Start the Session
// session_start() tells the server to look for an existing user session.
// This is how the system remembers if a user has already logged in.
session_start();

/**
 * FUNCTION: checkUserStatus
 * Purpose: Determines where to send the user based on their login state.
 */
function checkUserStatus() {
    
    // Check if the 'user_id' session variable exists.
    // This variable is usually set in your login.php after a successful login.
    if (isset($_SESSION['user_id'])) {
        
        // If the user is logged in, redirect them to the Dashboard.
        // header("Location: ...") is the PHP way of moving to another page.
        header("Location: dashboard.php");
        exit(); // Always use exit() after a header redirect to stop further code execution.
        
    } else {
        
        // If the user is NOT logged in, redirect them to the Login page.
        header("Location: login.php");
        exit();
    }
}

// Execute the status check function
checkUserStatus();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redirecting...</title>
    <style>
        /* Internal CSS for a clean "Good Looking" redirect screen */
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .loader-container {
            text-align: center;
            padding: 20px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .spinner {
            border: 4px solid #f3f3f3;
            border-top: 4px solid #007bff;
            border-radius: 50%;
            width: 40px;
            height: 40px;
            animation: spin 1s linear infinite;
            margin: 0 auto 10px;
        }
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
    </style>
</head>
<body>
    <div class="loader-container">
        <div class="spinner"></div>
        <p>Loading your financial tracker...</p>
        <small>If you are not redirected, <a href="login.php">click here</a>.</small>
    </div>
</body>
</html>