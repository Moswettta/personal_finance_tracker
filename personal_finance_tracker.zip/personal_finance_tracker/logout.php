<?php
/**
 * LOGOUT SCRIPT
 * Clears all session data and redirects to the login portal.
 */

// 1. Initialize the session to access it
session_start();

// 2. Unset all session variables
$_SESSION = array();

// 3. If a session cookie was used, expire it to fully clear the browser link
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 4. Destroy the session on the server
session_destroy();

/**
 * INTERNAL CSS & REDIRECT UI
 * Provides a brief visual confirmation before redirecting.
 */
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logging Out - International System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background: #f8f9fc;
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .logout-box {
            text-align: center;
            padding: 30px;
            background: white;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.05);
            border-top: 5px solid #4e73df;
        }
        .spinner-border {
            color: #4e73df;
            width: 3rem;
            height: 3rem;
        }
    </style>
    <meta http-equiv="refresh" content="2;url=login.php">
</head>
<body>

    <div class="logout-box">
        <div class="spinner-border mb-3" role="status"></div>
        <h4 class="fw-bold text-dark">Securing Session...</h4>
        <p class="text-muted mb-0">You are being logged out of the International Finance Tracker.</p>
        <small class="text-primary mt-2 d-block">Redirecting to login.php</small>
    </div>

</body>
</html>