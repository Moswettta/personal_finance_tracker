<?php
/**
 * MANAGE CATEGORIES - FULL CRUD
 * Fixed Delete Logic & Text-Based Actions
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$status_msg = "";

// --- 1. HANDLE DELETE (Fixed Logic) ---
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $sql = "DELETE FROM categories WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        $status_msg = "<div class='alert alert-delete'>🗑️ Category removed successfully.</div>";
    }
}

// --- 2. HANDLE CREATE ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $type = mysqli_real_escape_string($conn, $_POST['type']);
    $sql = "INSERT INTO categories (name, type) VALUES ('$name', '$type')";
    if (mysqli_query($conn, $sql)) {
        $status_msg = "<div class='alert alert-add'>✔️ Category '$name' created.</div>";
    }
}

// --- 3. HANDLE UPDATE ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_category'])) {
    $id = mysqli_real_escape_string($conn, $_POST['cat_id']);
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $sql = "UPDATE categories SET name = '$name' WHERE id = '$id'";
    if (mysqli_query($conn, $sql)) {
        $status_msg = "<div class='alert alert-edit'>✏️ Category updated successfully.</div>";
    }
}

// --- 4. FETCH DATA ---
$income_cats = mysqli_query($conn, "SELECT * FROM categories WHERE type = 'income' ORDER BY name ASC");
$expense_cats = mysqli_query($conn, "SELECT * FROM categories WHERE type = 'expense' ORDER BY name ASC");
?>

<style>
    /* Internal CSS for System Configuration Page */
    :root {
        --primary-blue: #4e73df;
        --success-green: #1cc88a;
        --danger-red: #e74a3b;
        --info-cyan: #36b9cc;
        --light-bg: #f8f9fc;
    }

    body { background-color: var(--light-bg); font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
    
    .config-container { padding: 30px; }
    .page-title { color: #3a3b45; font-weight: 800; margin-bottom: 25px; }

    /* Alert Styling */
    .alert { border: none; border-radius: 8px; color: #fff; font-weight: 600; padding: 15px; margin-bottom: 20px; }
    .alert-add { background-color: var(--success-green); }
    .alert-delete { background-color: var(--danger-red); }
    .alert-edit { background-color: var(--info-cyan); }

    /* Card & Box Styling */
    .form-box { background: #fff; padding: 25px; border-radius: 12px; border: 1px solid #e3e6f0; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.1); }
    .cat-card { border: none; border-radius: 12px; box-shadow: 0 .15rem 1.75rem 0 rgba(58,59,69,.05); background: #fff; }
    .card-header { font-weight: 700; border-bottom: 1px solid #f1f3f9; padding: 15px 20px; }
    
    /* List & Buttons */
    .list-group-item { border: none; border-bottom: 1px solid #f1f3f9; padding: 12px 20px; transition: 0.2s; }
    .list-group-item:hover { background-color: #fcfcfd; }
    
    .btn-custom { font-size: 0.75rem; font-weight: 800; text-transform: uppercase; padding: 4px 10px; border-radius: 4px; text-decoration: none; display: inline-block; }
    .btn-edit { color: var(--info-cyan); border: 1px solid var(--info-cyan); background: transparent; }
    .btn-edit:hover { background: var(--info-cyan); color: #fff; }
    .btn-del { color: var(--danger-red); border: 1px solid var(--danger-red); margin-left: 5px; }
    .btn-del:hover { background: var(--danger-red); color: #fff; }

    .label-mini { font-size: 0.65rem; color: #b7b9cc; font-weight: 800; text-transform: uppercase; }
</style>

<div class="container-fluid config-container">
    <h2 class="page-title">System Configuration</h2>
    
    <?php echo $status_msg; ?>

    <div class="row">
        <div class="col-lg-4 mb-4">
            <div class="form-box">
                <h5 class="fw-bold text-primary mb-3">Add Category</h5>
                <form action="manage_categories.php" method="POST">
                    <div class="mb-3">
                        <label class="label-mini">Name</label>
                        <input type="text" name="name" class="form-control" placeholder="e.g. Consulting" required>
                    </div>
                    <div class="mb-3">
                        <label class="label-mini">Type</label>
                        <select name="type" class="form-select" required>
                            <option value="income">Income</option>
                            <option value="expense">Expense</option>
                        </select>
                    </div>
                    <button type="submit" name="add_category" class="btn btn-primary w-100 fw-bold">CREATE</button>
                </form>
            </div>
        </div>

        <div class="col-lg-8">
            <div class="row">
                <div class="col-md-6 mb-4">
                    <div class="card cat-card">
                        <div class="card-header text-success">Income Sources</div>
                        <ul class="list-group list-group-flush">
                            <?php while($row = mysqli_fetch_assoc($income_cats)): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span class="fw-bold text-dark"><?php echo htmlspecialchars($row['name']); ?></span>
                                    <div>
                                        <button class="btn-custom btn-edit" onclick="openEdit(<?php echo $row['id']; ?>, '<?php echo $row['name']; ?>')">edit</button>
                                        <a href="manage_categories.php?action=delete&id=<?php echo $row['id']; ?>" class="btn-custom btn-del" onclick="return confirm('Confirm delete?')">del</a>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>

                <div class="col-md-6 mb-4">
                    <div class="card cat-card">
                        <div class="card-header text-danger">Expense Types</div>
                        <ul class="list-group list-group-flush">
                            <?php while($row = mysqli_fetch_assoc($expense_cats)): ?>
                                <li class="list-group-item d-flex justify-content-between align-items-center">
                                    <span class="fw-bold text-dark"><?php echo htmlspecialchars($row['name']); ?></span>
                                    <div>
                                        <button class="btn-custom btn-edit" onclick="openEdit(<?php echo $row['id']; ?>, '<?php echo $row['name']; ?>')">edit</button>
                                        <a href="manage_categories.php?action=delete&id=<?php echo $row['id']; ?>" class="btn-custom btn-del" onclick="return confirm('Confirm delete?')">del</a>
                                    </div>
                                </li>
                            <?php endwhile; ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="editModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="manage_categories.php" method="POST" class="modal-content border-0 shadow">
            <div class="modal-header bg-primary text-white">
                <h5 class="modal-title fw-bold">Update Category</h5>
                <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body p-4">
                <input type="hidden" name="cat_id" id="edit_id">
                <label class="label-mini">New Category Name</label>
                <input type="text" name="name" id="edit_name" class="form-control" required>
            </div>
            <div class="modal-footer border-0">
                <button type="submit" name="update_category" class="btn btn-primary fw-bold px-4">SAVE CHANGES</button>
            </div>
        </form>
    </div>
</div>

<script>
function openEdit(id, name) {
    document.getElementById('edit_id').value = id;
    document.getElementById('edit_name').value = name;
    var myModal = new bootstrap.Modal(document.getElementById('editModal'));
    myModal.show();
}
</script>

<?php include 'includes/footer.php'; ?>