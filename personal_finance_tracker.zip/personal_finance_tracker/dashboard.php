<?php
/**
 * FINANCIAL COMMAND CENTER - DASHBOARD
 * Features: Summary Cards, Expense Breakdown Chart, Recent Transactions
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$current_month = date('m');
$current_year = date('Y');

// 1. Fetch Totals for Summary Cards
$summary_sql = "SELECT 
                SUM(CASE WHEN c.type = 'income' THEN t.amount ELSE 0 END) as total_income,
                SUM(CASE WHEN c.type = 'expense' THEN t.amount ELSE 0 END) as total_expense
              FROM transactions t
              JOIN categories c ON t.category_id = c.id
              WHERE t.user_id = '$user_id' 
              AND MONTH(t.transaction_date) = '$current_month'
              AND YEAR(t.transaction_date) = '$current_year'";
$summary_res = mysqli_query($conn, $summary_sql);
$summary = mysqli_fetch_assoc($summary_res);

$total_inc = $summary['total_income'] ?? 0;
$total_exp = $summary['total_expense'] ?? 0;
$balance = $total_inc - $total_exp;

// 2. Fetch Chart Data (Strictly Expenses)
$pie_sql = "SELECT c.name, SUM(t.amount) as amt 
            FROM transactions t 
            JOIN categories c ON t.category_id = c.id 
            WHERE t.user_id = '$user_id' AND c.type = 'expense' 
            GROUP BY c.name";
$pie_res = mysqli_query($conn, $pie_sql);

$p_labels = []; 
$p_values = [];
while($row = mysqli_fetch_assoc($pie_res)){
    $p_labels[] = $row['name'];
    $p_values[] = (float)$row['amt']; // Ensure numeric type for JS
}
?>

<style>
    .card-summary { border: none; border-radius: 10px; transition: 0.3s; }
    .card-summary:hover { transform: translateY(-5px); }
    .border-left-income { border-left: 5px solid #1cc88a !important; }
    .border-left-expense { border-left: 5px solid #e74a3b !important; }
    .border-left-savings { border-left: 5px solid #4e73df !important; }
    .chart-area { height: 320px; position: relative; }
    .table-custom thead { background-color: #f8f9fc; }
    .badge-method { font-family: monospace; font-size: 0.8rem; }
</style>

<div class="container-fluid mt-4">
    <h2 class="fw-bold text-dark mb-4">Financial Command Center</h2>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-left-income h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Total Income</div>
                    <div class="h3 mb-0 fw-bold"><?php echo number_format($total_inc, 2); ?> KES</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-left-expense h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-danger text-uppercase mb-1">Total Expenses</div>
                    <div class="h3 mb-0 fw-bold"><?php echo number_format($total_exp, 2); ?> KES</div>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card card-summary shadow-sm border-left-savings h-100 py-2">
                <div class="card-body">
                    <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Net Savings</div>
                    <div class="h3 mb-0 fw-bold"><?php echo number_format($balance, 2); ?> KES</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        <div class="col-xl-4 col-lg-5 mb-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-header bg-white py-3">
                    <h6 class="m-0 fw-bold text-primary">Expense Breakdown</h6>
                </div>
                <div class="card-body">
                    <div class="chart-area">
                        <canvas id="myPieChart"></canvas>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-8 col-lg-7 mb-4">
            <div class="card shadow-sm border-0 h-100">
                <div class="card-header bg-white py-3 d-flex justify-content-between">
                    <h6 class="m-0 fw-bold text-primary">Recent Transactions</h6>
                    <a href="view_transactions.php" class="btn btn-sm btn-outline-primary">View All</a>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-custom table-hover align-middle">
                            <thead>
                                <tr>
                                    <th>Date</th>
                                    <th>Category</th>
                                    <th>Method</th>
                                    <th class="text-end">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                // Fetch transactions
                                $recent_sql = "SELECT t.*, c.name, c.type FROM transactions t 
                                               JOIN categories c ON t.category_id = c.id 
                                               WHERE t.user_id = '$user_id' 
                                               ORDER BY t.transaction_date DESC, t.id DESC LIMIT 5";
                                $recent_res = mysqli_query($conn, $recent_sql);
                                while($row = mysqli_fetch_assoc($recent_res)):
                                ?>
                                <tr>
                                    <td class="text-muted small"><?php echo $row['transaction_date']; ?></td>
                                    <td class="fw-bold"><?php echo htmlspecialchars($row['name']); ?></td>
                                    <td>
                                        <span class="badge bg-light text-dark border badge-method">
                                            <?php echo !empty($row['payment_method']) ? $row['payment_method'] : 'N/A'; ?>
                                        </span>
                                    </td>
                                    <td class="text-end fw-bold <?php echo ($row['type'] == 'income') ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo number_format($row['amount'], 2); ?>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Prepare data from PHP
    const chartLabels = <?php echo json_encode($p_labels); ?>;
    const chartData = <?php echo json_encode($p_values); ?>;

    const ctx = document.getElementById('myPieChart').getContext('2d');

    if (chartData.length === 0) {
        // Handle empty state visually
        ctx.font = "16px Arial";
        ctx.textAlign = "center";
        ctx.fillText("No expense data found.", ctx.canvas.width/2, ctx.canvas.height/2);
    } else {
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: chartLabels,
                datasets: [{
                    data: chartData,
                    backgroundColor: ['#e74a3b', '#4e73df', '#1cc88a', '#f6c23e', '#36b9cc'],
                    hoverOffset: 10,
                    borderWidth: 2,
                    borderColor: '#ffffff'
                }]
            },
            options: {
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { padding: 20 } }
                }
            }
        });
    }
</script>

<?php include 'includes/footer.php'; ?>