<?php
/**
 * ADD EXPENSE PAGE
 * This file handles recording money leaving the account.
 */

// 1. Load System Dependencies
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php'; // Includes Top-Nav and Sidebar

// Security: Protect the page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

// 2. Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);

    // Insert into transactions table matching your schema
    $sql = "INSERT INTO transactions (user_id, category_id, amount, description, payment_method, transaction_date) 
            VALUES ('$user_id', '$category_id', '$amount', '$description', '$payment_method', '$date')";

    if (mysqli_query($conn, $sql)) {
        $status_msg = "<div class='alert alert-danger shadow-sm border-0'>💸 Expense recorded successfully!</div>";
    } else {
        $status_msg = "<div class='alert alert-warning border-0 shadow-sm'>Error: " . mysqli_error($conn) . "</div>";
    }
}

// 3. Fetch ONLY Expense Categories for the dropdown
$cat_sql = "SELECT * FROM categories WHERE type = 'expense' ORDER BY name ASC";
$categories = mysqli_query($conn, $cat_sql);

// 4. Function to get current month's total for the sidebar summary
function getLocalTotalExpenses($conn, $user_id) {
    $month = date('m');
    $year = date('Y');
    $sql = "SELECT SUM(t.amount) as total FROM transactions t 
            JOIN categories c ON t.category_id = c.id 
            WHERE t.user_id = '$user_id' AND c.type = 'expense' 
            AND MONTH(t.transaction_date) = '$month' AND YEAR(t.transaction_date) = '$year'";
    $res = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($res);
    return $row['total'] ?? 0;
}
?>

<style>
    .expense-card {
        border: none;
        border-radius: 15px;
        background: #ffffff;
    }
    .expense-header {
        background: linear-gradient(45deg, #e74a3b, #be2617);
        color: white;
        border-radius: 15px 15px 0 0;
        padding: 20px;
    }
    .form-label {
        font-weight: 600;
        color: #e74a3b;
        margin-top: 10px;
    }
    .btn-save-expense {
        background: #e74a3b;
        color: white;
        font-weight: bold;
        padding: 12px;
        border-radius: 10px;
        border: none;
        transition: 0.3s;
    }
    .btn-save-expense:hover {
        background: #be2617;
        color: white;
        box-shadow: 0 4px 10px rgba(231, 74, 59, 0.3);
    }
    .summary-box {
        border-left: 4px solid #e74a3b;
        background: #fffcfc;
    }
</style>

<div class="container-fluid mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card expense-card shadow-sm mb-4">
                <div class="expense-header">
                    <h5 class="m-0"><i class="fas fa-shopping-cart me-2"></i> Log New Expenditure</h5>
                    <small class="text-white-50">International Financial Management</small>
                </div>
                <div class="card-body p-4">
                    
                    <?php echo $status_msg; ?>

                    <form action="add_expense.php" method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Amount Spent (KES)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0">KES</span>
                                    <input type="number" step="0.01" name="amount" class="form-control form-control-lg border-start-0" placeholder="0.00" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Transaction Date</label>
                                <input type="date" name="date" class="form-control form-control-lg" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Expense Category</label>
                                <select name="category_id" class="form-select form-control-lg" required>
                                    <option value="">-- Choose Category --</option>
                                    <?php while($row = mysqli_fetch_assoc($categories)): ?>
                                        <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['name']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Payment Mode</label>
                                <select name="payment_method" class="form-select form-control-lg">
                                    <option value="Cash" selected>Cash</option>
                                    <option value="M-Pesa">M-Pesa</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                    <option value="Credit Card">Credit Card</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label text-uppercase small">Description / Receipt Note</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="What was this expense for? (e.g. Electricity bill, Office lunch)"></textarea>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-save-expense">Confirm Expense Payment</button>
                            <a href="dashboard.php" class="btn btn-link text-muted small">Back to Dashboard</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card summary-box shadow-sm mb-4 border-0">
                <div class="card-body">
                    <h6 class="text-muted text-uppercase small font-weight-bold">This Month's Spending</h6>
                    <h2 class="text-danger font-weight-bold mb-0">
                        KES <?php echo number_format(getLocalTotalExpenses($conn, $user_id), 2); ?>
                    </h2>
                    <hr>
                    <p class="small text-muted mb-0"><i class="fas fa-chart-line text-danger me-1"></i> Tracking your spending helps you identify financial leaks early.</p>
                </div>
            </div>

            <div class="card border-0 shadow-sm p-3 bg-light rounded-3">
                <h6 class="font-weight-bold small text-dark"><i class="fas fa-shield-alt text-primary me-2"></i>Data Integrity</h6>
                <p class="small text-muted mb-0">
                    Once recorded, this transaction will appear in your <strong>History</strong> and update your <strong>Expense Breakdown</strong> chart automatically.
                </p>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>