<?php
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

// --- DELETE HANDLER ---
if (isset($_GET['delete_id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    $del_query = "DELETE FROM transactions WHERE id = '$id' AND user_id = '$user_id'";
    if (mysqli_query($conn, $del_query)) {
        $status_msg = "<div class='alert alert-secondary border-0 shadow-sm'>Record #$id has been removed.</div>";
    }
}

$sql = "SELECT t.*, c.name as cat_name, c.type as cat_type 
        FROM transactions t 
        JOIN categories c ON t.category_id = c.id 
        WHERE t.user_id = '$user_id' 
        ORDER BY t.transaction_date DESC";
$result = mysqli_query($conn, $sql);
?>

<style>
    /* CLEAN ACTION STYLING */
    .btn-action-outline {
        border: 1px solid #d1d3e2;
        background: transparent;
        color: #4e73df;
        font-size: 0.7rem;
        font-weight: 700;
        text-transform: uppercase;
        padding: 4px 10px;
        border-radius: 4px;
        transition: all 0.2s ease;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
    }
    .btn-action-outline:hover { border-color: #4e73df; background: #f8f9fc; color: #224abe; }
    .btn-delete-outline { color: #858796; }
    .btn-delete-outline:hover { border-color: #e74a3b; color: #e74a3b; }

    /* FLOW TYPE STYLING */
    .flow-indicator {
        font-size: 0.75rem;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.5px;
    }
    .text-income { color: #1cc88a; }
    .text-expense { color: #e74a3b; }

    .table-intl { border-collapse: separate; border-spacing: 0 8px; width: 100%; }
    .table-intl tr { background: #fff; box-shadow: 0 2px 4px rgba(0,0,0,0.02); }
    .table-intl td { border: none; padding: 12px 10px; vertical-align: middle; }
    .table-intl td:first-child { border-radius: 8px 0 0 8px; }
    .table-intl td:last-child { border-radius: 0 8px 8px 0; }
</style>

<div class="container-fluid mt-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="h4 fw-bold text-gray-800">Transaction Registry</h2>
        <div class="d-flex gap-2">
            <select id="typeFilter" class="form-select form-select-sm" style="width: 150px;">
                <option value="all">All Items</option>
                <option value="income">Income</option>
                <option value="expense">Expenditure</option>
            </select>
            <input type="text" id="tableSearch" class="form-control form-control-sm" placeholder="Search registry...">
        </div>
    </div>

    <?php echo $status_msg; ?>

    <div class="table-responsive">
        <table class="table table-intl" id="transactionTable">
            <thead>
                <tr class="text-uppercase small text-muted fw-bolder">
                    <th class="ps-3">Date</th>
                    <th>Flow Type</th> <th>Classification</th>
                    <th>Method</th>
                    <th class="text-end">Amount</th>
                    <th class="text-center">Operations</th>
                </tr>
            </thead>
            <tbody>
                <?php while($row = mysqli_fetch_assoc($result)): ?>
                <tr data-type="<?php echo $row['cat_type']; ?>">
                    <td class="ps-3 small text-muted">
                        <?php echo date('d M, Y', strtotime($row['transaction_date'])); ?>
                    </td>
                    
                    <td>
                        <?php if($row['cat_type'] == 'income'): ?>
                            <span class="flow-indicator text-income">
                                <i class="fas fa-arrow-down me-1"></i> Income
                            </span>
                        <?php else: ?>
                            <span class="flow-indicator text-expense">
                                <i class="fas fa-arrow-up me-1"></i> Expense
                            </span>
                        <?php endif; ?>
                    </td>

                    <td>
                        <div class="fw-bold text-dark"><?php echo htmlspecialchars($row['cat_name']); ?></div>
                        <small class="text-muted d-block" style="max-width: 200px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
                            <?php echo htmlspecialchars($row['description']); ?>
                        </small>
                    </td>

                    <td><span class="small text-secondary fw-bold"><?php echo $row['payment_method']; ?></span></td>
                    
                    <td class="text-end fw-bold <?php echo ($row['cat_type'] == 'income' ? 'text-income' : 'text-expense'); ?>">
                        <?php echo ($row['cat_type'] == 'income' ? '+' : '-'); ?>
                        <?php echo number_format($row['amount'], 2); ?>
                    </td>

                    <td class="text-center">
                        <div class="d-flex justify-content-center gap-2">
                            <a href="edit_transaction.php?id=<?php echo $row['id']; ?>" class="btn-action-outline">
                                <i class="fas fa-edit"></i> EDIT
                            </a>
                            <a href="view_transactions.php?delete_id=<?php echo $row['id']; ?>" 
                               class="btn-action-outline btn-delete-outline"
                               onclick="return confirm('Confirm permanent deletion?')">
                                <i class="fas fa-trash-alt"></i> DELETE
                            </a>
                        </div>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>



<script>
    const searchInput = document.getElementById('tableSearch');
    const filterSelect = document.getElementById('typeFilter');
    const rows = document.querySelectorAll('#transactionTable tbody tr');

    function applyFilters() {
        const query = searchInput.value.toLowerCase();
        const type = filterSelect.value;

        rows.forEach(row => {
            const text = row.innerText.toLowerCase();
            const rowType = row.getAttribute('data-type');
            const matchesSearch = text.includes(query);
            const matchesType = (type === 'all' || rowType === type);

            row.style.display = (matchesSearch && matchesType) ? '' : 'none';
        });
    }

    searchInput.addEventListener('keyup', applyFilters);
    filterSelect.addEventListener('change', applyFilters);
</script>

<?php include 'includes/footer.php'; ?>