<?php
/**
 * DATABASE CONNECTION FILE
 * This file connects the PHP application to the MySQL database.
 */

// 1. Database Configuration Variables
// On XAMPP, the default host is 'localhost', user is 'root', and password is empty ''
$host = "localhost";
$username = "root";
$password = ""; 
$dbname = "tracker_db"; // Make sure this matches the name you used in phpMyAdmin

/**
 * FUNCTION: connectToDatabase
 * Purpose: Attempts to establish a connection and returns the connection object.
 */
function connectToDatabase($h, $u, $p, $db) {
    
    // Create the connection using mysqli_connect()
    $connection = mysqli_connect($h, $u, $p, $db);

    // 2. Check the Connection
    // If the connection fails, die() stops the script and shows the error.
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }
    
    return $connection;
}

// 3. Initialize the connection
// We store it in a variable called $conn which is used in your login and register pages.
$conn = connectToDatabase($host, $username, $password, $dbname);

// 4. Set Charset
// This ensures special characters (like currency symbols) are handled correctly.
mysqli_set_charset($conn, "utf8");

?>