</div> <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <script>
        // DEBUG TEST: This will tell us if the JavaScript is loading correctly.
        // Once the dropdown works, you can delete this part.
        console.log("Bootstrap Script Loaded Successfully");
        
        // Manual Dropdown Init (Just in case the auto-init fails)
        var dropdownElementList = [].slice.call(document.querySelectorAll('.dropdown-toggle'))
        var dropdownList = dropdownElementList.map(function (dropdownToggleEl) {
          return new bootstrap.Dropdown(dropdownToggleEl)
        });
    </script>

</body>
</html>