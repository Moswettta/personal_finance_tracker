<div class="sidebar shadow d-none d-md-block">
    <div class="sidebar-header">
        <h4 class="text-white">FinanceTracker</h4>
        <small class="text-muted text-uppercase" style="font-size: 0.65rem; letter-spacing: 1px;">International System</small>
    </div>
    
    <ul class="nav-links p-0 mt-3">
        <li><a href="dashboard.php">📊 Dashboard</a></li>
        
        <li class="section-divider px-4 mt-3 mb-1 text-secondary small text-uppercase fw-bold">Transactions</li>
        <li><a href="add_income.php">💰 Add Income</a></li>
        <li><a href="add_expense.php">💸 Add Expense</a></li>
        <li><a href="view_transactions.php">📜 History / Audit</a></li>
        
        <li class="section-divider px-4 mt-3 mb-1 text-secondary small text-uppercase fw-bold">Planning</li>
        <li><a href="manage_budgets.php">📅 Monthly Budgets</a></li>
        <li><a href="report.php">📈 Financial Reports</a></li>

        <li class="section-divider px-4 mt-3 mb-1 text-secondary small text-uppercase fw-bold">Configuration</li>
        <li><a href="manage_categories.php">📁 Manage Categories /📥Income Sources</a></li>
        
        
        <hr class="text-secondary mx-3 mt-4">
        <li><a href="logout.php" class="text-danger">🚪 Logout</a></li>
    </ul>
</div>

<style>
    /* Custom Sidebar Styling */
    .sidebar {
        width: 250px;
        height: 100vh;
        background-color: #2c3e50;
        position: fixed;
        left: 0;
        top: 0;
        z-index: 1000;
        overflow-y: auto;
    }

    /* Custom Slim Scrollbar logic as requested */
    .sidebar::-webkit-scrollbar { width: 6px; }
    .sidebar::-webkit-scrollbar-track { background: transparent; }
    .sidebar::-webkit-scrollbar-thumb {
        background-color: #6c757d;
        border-radius: 10px;
    }

    .sidebar-header { 
        padding: 25px 20px; 
        background: #1a252f; 
        text-align: center; 
        position: sticky;
        top: 0;
    }
    
    .nav-links li { list-style: none; }
    .nav-links li a {
        padding: 12px 25px;
        display: block;
        color: #adb5bd;
        text-decoration: none;
        transition: 0.2s;
    }

    .nav-links li a:hover { 
        background: #34495e; 
        color: white; 
        padding-left: 30px; 
    }

    .section-divider { 
        font-size: 0.7rem; 
        letter-spacing: 0.5px; 
    }
</style>