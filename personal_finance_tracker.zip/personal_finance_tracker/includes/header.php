<?php
/**
 * UPDATED HEADER FILE
 * Includes a top navigation bar with a profile dropdown.
 * Integrated with Bootstrap 5 CDN for styling and layout.
 */

// 1. Session start - keeps the user logged in across pages
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personal Finance Tracker | International</title>
    
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <style>
        body { 
            background-color: #f8f9fc; 
            margin: 0; 
            font-family: 'Inter', system-ui, -apple-system, sans-serif;
        }
        
        /* Layout: Content is pushed 250px to the right to make room for the Sidebar */
        .main-content { 
            margin-left: 250px; 
            padding: 30px; 
            min-height: 100vh;
        }
        
        /* Top Navigation Bar Styling */
        .top-nav {
            margin-left: 250px;
            background-color: #ffffff;
            border-bottom: 1px solid #e3e6f0;
            padding: 10px 30px;
            z-index: 1020; /* Stays above content */
        }
        
        /* Styling for the user profile dropdown */
        .user-dropdown-toggle {
            color: #5a5c69 !important;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
        }

        /* This fixes the "Bulleted List" issue seen in your screenshot */
        .navbar-nav {
            list-style: none !important;
            padding-left: 0;
            margin-bottom: 0;
        }

        .dropdown-menu {
            border: none;
            box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
            border-radius: 8px;
        }

        /* Sidebar adjustment for mobile */
        @media (max-width: 768px) {
            .main-content, .top-nav { margin-left: 0; }
        }
    </style>
</head>
<body>

<nav class="navbar navbar-expand top-nav sticky-top">
    <div class="container-fluid">
        <span class="navbar-text d-none d-sm-inline">
            Logged in as: <span class="text-primary fw-bold"><?php echo isset($_SESSION['user_name']) ? htmlspecialchars($_SESSION['user_name']) : 'Admin'; ?></span>
        </span>
        
        <div class="ms-auto">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle user-dropdown-toggle" href="#" id="userProfileMenu" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        <span class="mr-2 d-none d-lg-inline text-gray-600 small">Account</span>
                        <img class="img-profile rounded-circle" src="https://ui-avatars.com/api/?name=<?php echo $_SESSION['user_name']; ?>&background=4e73df&color=fff" width="30" height="30">
                    </a>
                    
                    <ul class="dropdown-menu dropdown-menu-end shadow animated--grow-in" aria-labelledby="userProfileMenu">
                        <li><a class="dropdown-item py-2" href="profile.php">⚙️ My Profile</a></li>
                        <li><a class="dropdown-item py-2" href="settings.php">🔧 Settings</a></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item py-2 text-danger" href="logout.php">🚪 Logout</a></li>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<?php include('sidebar.php'); ?>

<div class="main-content">