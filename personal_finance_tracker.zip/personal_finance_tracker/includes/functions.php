<?php
/**
 * FUNCTIONS LIBRARY
 * This file contains all the mathematical logic for calculating balances.
 */

/**
 * FUNCTION: getTotalIncome
 * Purpose: Calculates the sum of all 'income' transactions for a specific user.
 */
function getTotalIncome($conn, $user_id) {
    // We use the SQL SUM() function for speed and efficiency
    $sql = "SELECT SUM(amount) AS total FROM transactions 
            WHERE user_id = '$user_id' 
            AND category_id IN (SELECT id FROM categories WHERE type = 'income')";
    
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    
    // If the result is null (no transactions yet), return 0
    return $row['total'] ? $row['total'] : 0;
}

/**
 * FUNCTION: getTotalExpenses
 * Purpose: Calculates the sum of all 'expense' transactions.
 */
function getTotalExpenses($conn, $user_id) {
    $sql = "SELECT SUM(amount) AS total FROM transactions 
            WHERE user_id = '$user_id' 
            AND category_id IN (SELECT id FROM categories WHERE type = 'expense')";
    
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    
    return $row['total'] ? $row['total'] : 0;
}

/**
 * FUNCTION: getNetBalance
 * Purpose: Subtracts expenses from income to show the current wallet balance.
 */
function getNetBalance($conn, $user_id) {
    $income = getTotalIncome($conn, $user_id);
    $expenses = getTotalExpenses($conn, $user_id);
    
    return $income - $expenses;
}

/**
 * FUNCTION: formatCurrency
 * Purpose: Ensures all money values look professional (e.g., 1,000.00).
 */
function formatCurrency($amount) {
    // number_format(variable, decimals, decimal_point, thousands_separator)
    return "KES " . number_format($amount, 2, '.', ',');
}

/**
 * FUNCTION: getBudgetProgress
 * Purpose: Calculates what percentage of a budget has been spent.
 */
function getBudgetProgress($spent, $limit) {
    if ($limit <= 0) return 0;
    $percentage = ($spent / $limit) * 100;
    return round($percentage, 0); // Returns a whole number
}
?>