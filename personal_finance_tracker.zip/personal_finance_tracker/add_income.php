<?php
/**
 * ADD INCOME PAGE
 * This file handles recording money entering the account.
 */

// 1. Load System Dependencies
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php'; // This includes your sidebar and top-nav

// Security: Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

// 2. Handle Form Submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $date = mysqli_real_escape_string($conn, $_POST['date']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);

    // SQL Insert matching your 'transactions' table schema
    $sql = "INSERT INTO transactions (user_id, category_id, amount, description, payment_method, transaction_date) 
            VALUES ('$user_id', '$category_id', '$amount', '$description', '$payment_method', '$date')";

    if (mysqli_query($conn, $sql)) {
        $status_msg = "<div class='alert alert-success shadow-sm border-0'>💰 Income recorded successfully!</div>";
    } else {
        $status_msg = "<div class='alert alert-warning'>Error: " . mysqli_error($conn) . "</div>";
    }
}

// 3. Fetch ONLY Income Categories (Sources)
$cat_sql = "SELECT * FROM categories WHERE type = 'income' ORDER BY name ASC";
$categories = mysqli_query($conn, $cat_sql);
?>

<style>
    .income-card {
        border: none;
        border-radius: 15px;
        background: #ffffff;
    }
    .income-header {
        background: linear-gradient(45deg, #1cc88a, #13855c);
        color: white;
        border-radius: 15px 15px 0 0;
        padding: 20px;
    }
    .form-label {
        font-weight: 600;
        color: #1cc88a;
        margin-top: 10px;
    }
    .btn-save-income {
        background: #1cc88a;
        color: white;
        font-weight: bold;
        padding: 12px;
        border-radius: 10px;
        border: none;
        transition: 0.3s;
    }
    .btn-save-income:hover {
        background: #13855c;
        color: white;
        box-shadow: 0 4px 10px rgba(28, 200, 138, 0.3);
    }
</style>

<div class="container-fluid">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <div class="card income-card shadow-sm mb-4">
                <div class="income-header">
                    <h5 class="m-0"><i class="fas fa-plus-circle"></i> Log New Income Source</h5>
                </div>
                <div class="card-body p-4">
                    
                    <?php echo $status_msg; ?>

                    <form action="add_income.php" method="POST">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Amount Received (KES)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-end-0">KES</span>
                                    <input type="number" step="0.01" name="amount" class="form-control form-control-lg border-start-0" placeholder="0.00" required>
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Date Received</label>
                                <input type="date" name="date" class="form-control form-control-lg" value="<?php echo date('Y-m-d'); ?>" required>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Income Source / Category</label>
                                <select name="category_id" class="form-select form-control-lg" required>
                                    <option value="">-- Choose Source --</option>
                                    <?php while($row = mysqli_fetch_assoc($categories)): ?>
                                        <option value="<?php echo $row['id']; ?>"><?php echo htmlspecialchars($row['name']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label text-uppercase small">Payment Method</label>
                                <select name="payment_method" class="form-select form-control-lg">
                                    <option value="Cash" selected>Cash</option>
                                    <option value="M-Pesa">M-Pesa</option>
                                    <option value="Bank Transfer">Bank Transfer</option>
                                </select>
                            </div>
                        </div>

                        <div class="mb-4">
                            <label class="form-label text-uppercase small">Description / Remarks</label>
                            <textarea name="description" class="form-control" rows="3" placeholder="Additional details (e.g. Freelance project payment)"></textarea>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-save-income">Confirm & Deposit</button>
                            <a href="dashboard.php" class="btn btn-link text-muted">Back to Dashboard</a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="card border-0 shadow-sm p-4 bg-light rounded-3">
                <h6 class="fw-bold text-success text-uppercase small">Why log income?</h6>
                <p class="small text-muted">Tracking every coin that enters your wallet helps the system calculate your <strong>Net Position</strong> accurately against your budgets.</p>
                <hr>
                <h6 class="fw-bold text-dark small">Recent Activity</h6>
                <p class="small text-muted mb-0">Visit the <strong>History</strong> page to see previously logged revenue.</p>
            </div>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>