<?php
/**
 * PROJECT: Personal Finance Tracker
 * MODULE: Budget Management (CRUD)
 * PURPOSE: Handles creation, viewing, updating, and deletion of monthly spending limits.
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";
$current_period = date('Y-m'); 

/**
 * 1. DELETE HANDLER (CRUD: Delete)
 * Checks if a delete request is sent via GET and matches the user's ID for security.
 */
if (isset($_GET['delete_id'])) {
    $del_id = mysqli_real_escape_string($conn, $_GET['delete_id']);
    $del_query = "DELETE FROM budgets WHERE id = '$del_id' AND user_id = '$user_id'";
    if (mysqli_query($conn, $del_query)) {
        $status_msg = "<div class='alert alert-secondary border-0 shadow-sm'>🗑️ Budget allocation removed successfully.</div>";
    }
}

/**
 * 2. SAVE/UPDATE HANDLER (CRUD: Create & Update)
 * Uses an UPSERT logic (Update or Insert) to prevent duplicate categories in the same month.
 */
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save_budget'])) {
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $limit_amount = mysqli_real_escape_string($conn, $_POST['limit_amount']);
    $period = mysqli_real_escape_string($conn, $_POST['month_year']);

    $check_sql = "SELECT id FROM budgets WHERE user_id='$user_id' AND category_id='$category_id' AND month_year='$period'";
    $check_res = mysqli_query($conn, $check_sql);
    
    if (mysqli_num_rows($check_res) > 0) {
        // UPDATE existing record
        $sql = "UPDATE budgets SET limit_amount='$limit_amount' WHERE user_id='$user_id' AND category_id='$category_id' AND month_year='$period'";
    } else {
        // CREATE new record
        $sql = "INSERT INTO budgets (user_id, category_id, limit_amount, month_year) VALUES ('$user_id', '$category_id', '$limit_amount', '$period')";
    }

    if (mysqli_query($conn, $sql)) {
        $status_msg = "<div class='alert alert-success border-0 shadow-sm'>✅ Budget limit updated for $period.</div>";
    }
}

/**
 * 3. READ HANDLER (CRUD: Read)
 * Fetches the list of budgets joined with categories and calculates real-time spending.
 */
$budget_sql = "SELECT b.*, c.name as cat_name, 
               (SELECT SUM(amount) FROM transactions 
                WHERE category_id = b.category_id 
                AND user_id = b.user_id 
                AND DATE_FORMAT(transaction_date, '%Y-%m') = b.month_year) as spent
               FROM budgets b 
               JOIN categories c ON b.category_id = c.id 
               WHERE b.user_id = '$user_id' AND b.month_year = '$current_period'";
$budgets = mysqli_query($conn, $budget_sql);
?>

<style>
    .card { border: none; border-radius: 12px; }
    .progress { height: 10px; background-color: #f1f3f9; border-radius: 20px; }
    .btn-save { background: #4e73df; color: white; font-weight: 700; border-radius: 8px; padding: 10px; }
    .stat-label { font-size: 0.75rem; text-transform: uppercase; font-weight: 700; color: #858796; }
    .variance-badge { font-size: 0.7rem; padding: 4px 8px; border-radius: 4px; font-weight: 800; }
    .bg-light-success { background-color: #d1e7dd; color: #0f5132; }
    .bg-light-danger { background-color: #f8d7da; color: #842029; }
    .btn-delete-small { color: #e74a3b; font-size: 0.8rem; text-decoration: none; font-weight: 600; }
    .btn-delete-small:hover { color: #be2617; }
</style>

<div class="container-fluid mt-4">
    <div class="row">
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm p-4 h-100">
                <h5 class="fw-bold mb-3 text-gray-800">Plan Monthly Limit</h5>
                <form action="" method="POST">
                    <div class="mb-3">
                        <label class="stat-label">Target Month</label>
                        <input type="month" name="month_year" class="form-control" value="<?php echo $current_period; ?>" required>
                    </div>
                    <div class="mb-3">
                        <label class="stat-label">Category</label>
                        <select name="category_id" class="form-select" required>
                            <?php
                            $cat_res = mysqli_query($conn, "SELECT id, name FROM categories WHERE type='expense' ORDER BY name ASC");
                            while($cat = mysqli_fetch_assoc($cat_res)) {
                                echo "<option value='{$cat['id']}'>{$cat['name']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label class="stat-label">Amount (KES)</label>
                        <input type="number" step="0.01" name="limit_amount" class="form-control" placeholder="0.00" required>
                    </div>
                    <button type="submit" name="save_budget" class="btn btn-save w-100 shadow-sm">COMMIT BUDGET</button>
                </form>
            </div>
        </div>

        <div class="col-md-8">
            <?php echo $status_msg; ?>
            <div class="card shadow-sm p-4">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h5 class="fw-bold text-gray-800 mb-0">Variance Analysis: <?php echo date('F Y', strtotime($current_period."-01")); ?></h5>
                </div>
                
                <?php if (mysqli_num_rows($budgets) > 0): ?>
                    <?php while($row = mysqli_fetch_assoc($budgets)): 
                        $spent = $row['spent'] ?? 0;
                        $limit = $row['limit_amount'];
                        $variance = $limit - $spent; 
                        $percent = ($limit > 0) ? ($spent / $limit) * 100 : 0;
                        
                        $color = "bg-success";
                        if($percent > 100) $color = "bg-danger";
                        elseif($percent > 80) $color = "bg-warning";
                    ?>
                    <div class="mb-4 p-3 border rounded shadow-sm bg-white">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <div>
                                <span class="fw-bold text-dark h6 mb-0"><?php echo htmlspecialchars($row['cat_name']); ?></span>
                                <a href="manage_budgets.php?delete_id=<?php echo $row['id']; ?>" 
                                   class="ms-2 btn-delete-small" 
                                   onclick="return confirm('Remove this budget limit?')">
                                   <i class="fas fa-trash"></i> DELETE
                                </a>
                            </div>
                            <?php if($variance >= 0): ?>
                                <span class="variance-badge bg-light-success">
                                    <i class="fas fa-arrow-down me-1"></i> SURPLUS: KES <?php echo number_format($variance, 2); ?>
                                </span>
                            <?php else: ?>
                                <span class="variance-badge bg-light-danger">
                                    <i class="fas fa-arrow-up me-1"></i> DEFICIT: KES <?php echo number_format(abs($variance), 2); ?>
                                </span>
                            <?php endif; ?>
                        </div>

                        <div class="progress mb-2">
                            <div class="progress-bar <?php echo $color; ?> progress-bar-striped" role="progressbar" style="width: <?php echo min($percent, 100); ?>%"></div>
                        </div>

                        <div class="d-flex justify-content-between small text-muted">
                            <span>Used: <strong><?php echo number_format($spent, 2); ?></strong></span>
                            <span>Limit: <strong><?php echo number_format($limit, 2); ?></strong></span>
                            <span><?php echo round($percent, 1); ?>%</span>
                        </div>
                    </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-folder-open fa-3x text-gray-200 mb-3"></i>
                        <p class="text-muted">No active budget registry for this month.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>