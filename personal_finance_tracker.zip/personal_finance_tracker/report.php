<?php
/**
 * FINANCIAL REPORTING MODULE
 * Focus: Objective 1.3.2 (6 & 7) - Daily, Monthly, and Annual Reports
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Default Filter Settings
$filter_type = $_GET['filter_type'] ?? 'monthly';
$selected_date = $_GET['report_date'] ?? date('Y-m');

// Logic to build SQL date constraint
$date_condition = "";
if ($filter_type == 'daily') {
    $date_condition = "AND t.transaction_date = '$selected_date'";
    $display_title = "Daily Report: " . date('d M, Y', strtotime($selected_date));
} elseif ($filter_type == 'annual') {
    $year = date('Y', strtotime($selected_date));
    $date_condition = "AND YEAR(t.transaction_date) = '$year'";
    $display_title = "Annual Report: " . $year;
} else { // Monthly default
    $month = date('m', strtotime($selected_date));
    $year = date('Y', strtotime($selected_date));
    $date_condition = "AND MONTH(t.transaction_date) = '$month' AND YEAR(t.transaction_date) = '$year'";
    $display_title = "Monthly Report: " . date('F Y', strtotime($selected_date));
}

// 1. Fetch Totals for the selected period
$summary_sql = "SELECT 
                SUM(CASE WHEN c.type = 'income' THEN t.amount ELSE 0 END) as total_inc,
                SUM(CASE WHEN c.type = 'expense' THEN t.amount ELSE 0 END) as total_exp
                FROM transactions t 
                JOIN categories c ON t.category_id = c.id
                WHERE t.user_id = '$user_id' $date_condition";
$summary_res = mysqli_query($conn, $summary_sql);
$totals = mysqli_fetch_assoc($summary_res);

$income = $totals['total_inc'] ?? 0;
$expense = $totals['total_exp'] ?? 0;
$net = $income - $expense;

// 2. Fetch Itemized Data for Table
$report_sql = "SELECT t.*, c.name as cat_name, c.type 
               FROM transactions t 
               JOIN categories c ON t.category_id = c.id 
               WHERE t.user_id = '$user_id' $date_condition 
               ORDER BY t.transaction_date DESC";
$report_res = mysqli_query($conn, $report_sql);
?>

<style>
    :root {
        --dark-navy: #2c3e50;
        --soft-grey: #f4f7f6;
    }
    body { background-color: var(--soft-grey); }
    .report-card { border: none; border-radius: 15px; box-shadow: 0 4px 12px rgba(0,0,0,0.05); }
    .filter-section { background: #fff; padding: 20px; border-radius: 15px; margin-bottom: 25px; border: 1px solid #e0e0e0; }
    .stat-box { padding: 20px; border-radius: 12px; color: #fff; text-align: center; }
    .bg-income { background: linear-gradient(45deg, #1cc88a, #13855c); }
    .bg-expense { background: linear-gradient(45deg, #e74a3b, #be2617); }
    .bg-balance { background: linear-gradient(45deg, #4e73df, #224abe); }
    .print-btn { background-color: var(--dark-navy); color: #fff; border-radius: 8px; font-weight: 600; }
    
    @media print {
        .filter-section, .print-btn, .nav-sidebar { display: none !important; }
        .container-fluid { width: 100%; padding: 0; }
    }
</style>

<div class="container-fluid py-4">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2 class="fw-bold text-dark m-0">Financial Reporting</h2>
        <button onclick="window.print()" class="btn print-btn px-4">Download PDF / Print</button>
    </div>

    <div class="filter-section shadow-sm">
        <form method="GET" class="row g-3 align-items-end">
            <div class="col-md-3">
                <label class="form-label small fw-bold text-muted">REPORT TYPE</label>
                <select name="filter_type" class="form-select border-0 bg-light">
                    <option value="daily" <?php if($filter_type=='daily') echo 'selected'; ?>>Daily</option>
                    <option value="monthly" <?php if($filter_type=='monthly') echo 'selected'; ?>>Monthly</option>
                    <option value="annual" <?php if($filter_type=='annual') echo 'selected'; ?>>Annual</option>
                </select>
            </div>
            <div class="col-md-3">
                <label class="form-label small fw-bold text-muted">SELECT DATE</label>
                <input type="date" name="report_date" class="form-control border-0 bg-light" value="<?php echo substr($selected_date, 0, 10); ?>">
            </div>
            <div class="col-md-2">
                <button type="submit" class="btn btn-primary w-100 fw-bold">GENERATE</button>
            </div>
        </form>
    </div>

    <div class="row mb-4">
        <div class="col-md-4">
            <div class="stat-box bg-income shadow">
                <div class="small text-uppercase opacity-75">Total Income</div>
                <h3 class="fw-bold mb-0">KES <?php echo number_format($income, 2); ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-box bg-expense shadow">
                <div class="small text-uppercase opacity-75">Total Expenses</div>
                <h3 class="fw-bold mb-0">KES <?php echo number_format($expense, 2); ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="stat-box bg-balance shadow">
                <div class="small text-uppercase opacity-75">Net Balance</div>
                <h3 class="fw-bold mb-0">KES <?php echo number_format($net, 2); ?></h3>
            </div>
        </div>
    </div>

    <div class="card report-card overflow-hidden">
        <div class="card-header bg-white py-3 border-0">
            <h5 class="m-0 fw-bold text-primary"><?php echo $display_title; ?></h5>
        </div>
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="bg-light">
                        <tr>
                            <th class="ps-4">Date</th>
                            <th>Category</th>
                            <th>Description</th>
                            <th>Method</th>
                            <th class="text-end pe-4">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if(mysqli_num_rows($report_res) > 0): ?>
                            <?php while($row = mysqli_fetch_assoc($report_res)): ?>
                                <tr>
                                    <td class="ps-4 small text-muted"><?php echo $row['transaction_date']; ?></td>
                                    <td><span class="fw-bold"><?php echo htmlspecialchars($row['cat_name']); ?></span></td>
                                    <td class="text-muted"><?php echo htmlspecialchars($row['description']); ?></td>
                                    <td><span class="badge bg-light text-dark border"><?php echo $row['payment_method']; ?></span></td>
                                    <td class="text-end pe-4 fw-bold <?php echo ($row['type']=='income') ? 'text-success' : 'text-danger'; ?>">
                                        <?php echo ($row['type']=='income' ? '+' : '-') . number_format($row['amount'], 2); ?>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">No transactions found for this period.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>