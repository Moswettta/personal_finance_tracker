<?php
/**
 * EDIT TRANSACTION (CRUD: UPDATE)
 * Fetches existing record data and updates it based on User ID security.
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

// 1. GET TRANSACTION DATA (READ)
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($conn, $_GET['id']);
    $query = "SELECT * FROM transactions WHERE id = '$id' AND user_id = '$user_id'";
    $result = mysqli_query($conn, $query);
    $transaction = mysqli_fetch_assoc($result);

    if (!$transaction) {
        die("<div class='container mt-5'><div class='alert alert-danger'>Transaction not found or access denied.</div></div>");
    }
} else {
    header("Location: view_transactions.php");
    exit();
}

// 2. HANDLE UPDATE LOGIC (UPDATE)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_transaction'])) {
    $category_id = mysqli_real_escape_string($conn, $_POST['category_id']);
    $amount = mysqli_real_escape_string($conn, $_POST['amount']);
    $description = mysqli_real_escape_string($conn, $_POST['description']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $transaction_date = mysqli_real_escape_string($conn, $_POST['transaction_date']);

    $update_sql = "UPDATE transactions SET 
                    category_id = '$category_id', 
                    amount = '$amount', 
                    description = '$description', 
                    payment_method = '$payment_method', 
                    transaction_date = '$transaction_date' 
                   WHERE id = '$id' AND user_id = '$user_id'";

    if (mysqli_query($conn, $update_sql)) {
        $status_msg = "<div class='alert alert-success border-0 shadow-sm'>✅ Transaction updated successfully! <a href='view_transactions.php'>View Registry</a></div>";
        // Refresh local data for the form
        $query = "SELECT * FROM transactions WHERE id = '$id' AND user_id = '$user_id'";
        $result = mysqli_query($conn, $query);
        $transaction = mysqli_fetch_assoc($result);
    } else {
        $status_msg = "<div class='alert alert-danger'>Update failed: " . mysqli_error($conn) . "</div>";
    }
}
?>

<style>
    .edit-card { border: none; border-radius: 15px; background: #fff; }
    .form-label-intl { font-size: 0.75rem; font-weight: 800; color: #4e73df; text-transform: uppercase; margin-bottom: 5px; }
    .input-intl { border-radius: 8px; border: 1px solid #d1d3e2; padding: 12px; }
    .btn-update-intl { background: #4e73df; color: white; border: none; padding: 12px; border-radius: 8px; font-weight: bold; width: 100%; transition: 0.3s; }
    .btn-update-intl:hover { background: #224abe; box-shadow: 0 4px 12px rgba(78,115,223,0.3); color: white; }
</style>

<div class="container mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-6">
            <div class="d-flex align-items-center mb-4">
                <a href="view_transactions.php" class="btn btn-sm btn-outline-secondary me-3"><i class="fas fa-arrow-left"></i></a>
                <h2 class="h4 fw-bold mb-0">Modify Transaction #<?php echo $id; ?></h2>
            </div>

            <?php echo $status_msg; ?>

            <div class="card edit-card shadow-sm">
                <div class="card-body p-4">
                    <form action="" method="POST">
                        <div class="mb-3">
                            <label class="form-label-intl">Category Classification</label>
                            <select name="category_id" class="form-select input-intl" required>
                                <?php
                                $cat_query = mysqli_query($conn, "SELECT * FROM categories ORDER BY name ASC");
                                while($cat = mysqli_fetch_assoc($cat_query)) {
                                    $selected = ($cat['id'] == $transaction['category_id']) ? "selected" : "";
                                    echo "<option value='{$cat['id']}' $selected>{$cat['name']} ({$cat['type']})</option>";
                                }
                                ?>
                            </select>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="form-label-intl">Amount (KES)</label>
                                <input type="number" step="0.01" name="amount" class="form-control input-intl" 
                                       value="<?php echo $transaction['amount']; ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="form-label-intl">Execution Date</label>
                                <input type="date" name="transaction_date" class="form-control input-intl" 
                                       value="<?php echo $transaction['transaction_date']; ?>" required>
                            </div>
                        </div>

                        <div class="mb-3">
                            <label class="form-label-intl">Payment Method</label>
                            <select name="payment_method" class="form-select input-intl">
                                <option value="Cash" <?php if($transaction['payment_method'] == 'Cash') echo 'selected'; ?>>Cash</option>
                                <option value="M-Pesa" <?php if($transaction['payment_method'] == 'M-Pesa') echo 'selected'; ?>>M-Pesa</option>
                                <option value="Bank Transfer" <?php if($transaction['payment_method'] == 'Bank Transfer') echo 'selected'; ?>>Bank Transfer</option>
                            </select>
                        </div>

                        <div class="mb-4">
                            <label class="form-label-intl">Notes / Description</label>
                            <textarea name="description" class="form-control input-intl" rows="3"><?php echo htmlspecialchars($transaction['description']); ?></textarea>
                        </div>

                        <button type="submit" name="update_transaction" class="btn-update-intl shadow-sm">
                            <i class="fas fa-sync-alt me-2"></i>COMMIT CHANGES
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>