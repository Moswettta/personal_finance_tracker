<?php
/**
 * USER PROFILE - FULL CRUD
 * Handles Reading data, Updating personal info, and Updating Security (Password).
 */
require_once 'config/db.php';
require_once 'includes/functions.php';
require_once 'includes/header.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$status_msg = "";

// --- 1. HANDLE PROFILE & PASSWORD UPDATES (CRUD: U) ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_account'])) {
    $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $current_pass = $_POST['current_password'];
    $new_pass = $_POST['new_password'];

    // First, verify the current password from the database
    $verify_sql = "SELECT password FROM users WHERE id = '$user_id'";
    $verify_res = mysqli_query($conn, $verify_sql);
    $user_data = mysqli_fetch_assoc($verify_res);

    if (password_verify($current_pass, $user_data['password'])) {
        // Current password is correct, proceed with updates
        if (!empty($new_pass)) {
            // User wants to change password
            $hashed_pass = password_hash($new_pass, PASSWORD_DEFAULT);
            $sql = "UPDATE users SET full_name='$full_name', email='$email', password='$hashed_pass' WHERE id='$user_id'";
        } else {
            // User only wants to update name/email
            $sql = "UPDATE users SET full_name='$full_name', email='$email' WHERE id='$user_id'";
        }

        if (mysqli_query($conn, $sql)) {
            $status_msg = "<div class='alert alert-success border-0 shadow-sm'>✅ Account and Security updated successfully!</div>";
        } else {
            $status_msg = "<div class='alert alert-danger'>Database Error: " . mysqli_error($conn) . "</div>";
        }
    } else {
        $status_msg = "<div class='alert alert-warning border-0 shadow-sm'>❌ Current password is incorrect. No changes made.</div>";
    }
}

// --- 2. FETCH CURRENT DATA (CRUD: R) ---
$user_query = mysqli_query($conn, "SELECT * FROM users WHERE id = '$user_id'");
$user = mysqli_fetch_assoc($user_query);
?>

<style>
    .profile-card { border: none; border-radius: 15px; background: #fff; }
    .profile-header {
        background: linear-gradient(135deg, #4e73df 0%, #224abe 100%);
        color: white; padding: 40px 20px; border-radius: 15px 15px 0 0; text-align: center;
    }
    .avatar-circle {
        width: 90px; height: 90px; background: rgba(255,255,255,0.2);
        border: 3px solid #fff; border-radius: 50%; display: flex;
        align-items: center; justify-content: center; margin: 0 auto 15px;
        font-size: 2.2rem; font-weight: bold;
    }
    .section-title { font-size: 0.8rem; font-weight: 800; color: #4e73df; text-transform: uppercase; letter-spacing: 1px; }
    .btn-intl { background: #4e73df; color: white; border: none; padding: 12px; border-radius: 8px; font-weight: bold; transition: 0.3s; }
    .btn-intl:hover { background: #224abe; box-shadow: 0 4px 12px rgba(78,115,223,0.3); color: white; }
</style>

<div class="container-fluid mt-4">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <?php echo $status_msg; ?>
            
            <div class="card profile-card shadow-sm mb-5">
                <div class="profile-header">
                    <div class="avatar-circle"><?php echo strtoupper(substr($user['full_name'], 0, 1)); ?></div>
                    <h4 class="mb-0 fw-bold"><?php echo htmlspecialchars($user['full_name']); ?></h4>
                    <p class="small mb-0 opacity-75">International Finance Administrator</p>
                </div>
                
                <div class="card-body p-4">
                    <form action="profile.php" method="POST">
                        <h6 class="section-title mb-3"><i class="fas fa-user me-2"></i>Personal Details</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="small text-muted fw-bold">Full Name</label>
                                <input type="text" name="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="small text-muted fw-bold">Email Address</label>
                                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            </div>
                        </div>

                        <hr class="my-4">

                        <h6 class="section-title mb-3"><i class="fas fa-lock me-2"></i>Security & Authentication</h6>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label class="small text-muted fw-bold">Current Password <span class="text-danger">*</span></label>
                                <input type="password" name="current_password" class="form-control" placeholder="Required to save changes" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label class="small text-muted fw-bold">New Password (Optional)</label>
                                <input type="password" name="new_password" class="form-control" placeholder="Leave blank to keep current">
                            </div>
                        </div>

                        <div class="mt-4 d-grid gap-2">
                            <button type="submit" name="update_account" class="btn btn-intl">
                                Save All Changes
                            </button>
                            <a href="dashboard.php" class="btn btn-link text-muted small">Discard Changes</a>
                        </div>
                    </form>
                </div>
                
                <div class="card-footer bg-light text-center border-0 py-3">
                    <small class="text-muted">Account Registered: <?php echo $user['created_at']; ?></small>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>